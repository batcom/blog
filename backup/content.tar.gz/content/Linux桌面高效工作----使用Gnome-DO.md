Title: Linux桌面高效工作----使用Gnome DO
Tags: 高效,桌面,Linux,gnome do
Category: Linux
Date: 2012-09-01 08:03
不知大家是否和我一样在win下系统win+r输入命令来快速启动程序,这两天在Linux下碰到一个比这更爽,更快的软件,`Gnome Do`.

Gnome Do能根据用户键入的内容进行自动匹配，从而快速打开系统中已有的程序、文件、书签等。不仅如此，GNOME Do 还包括插件，从而能够做更多事,

比如你安装了pidgin插件只需输入联系人的名字即可打开与他/她的会话,安装了file这个插件输入文件/目录的名字即可打开目录或文件,

当然还有一个不足就是不支持中文

ubuntu用户可以按照下面安装:
```bash
sudo apt-get install gnome-do
```
启动之后Gnome do不会停留任务栏或通知栏只需按`Win(ubuntu下称为super)+Space`即可启动,输入你想启动的应用程序名字即可打开/关闭等操作.是不是很酷提高不少的工作效率
