Title: 用bottle+mongodb写的blog程序支持mysql啦
Tags: 支持mysql,web,python,MySQL,mongodb,bottle,blog
Category: Python
Date: 2012-08-14 09:16
前面博文提到过,本人用bottle+mongodb实现了以blog程序,

最近有些空闲时间,就重新用mvc的模式重写了一下,因为mongodb太过耗费内存,对一些小型的vps太过吃力所以加入了mysql的支持,

虽然较上次有些完善,但是还是有很多不足代码放在了googlecode上,由于最近一直在使用git,索性也就新建了一个git的项目,之前svn的项目也会更新.

所以大家想浏览代码可以到下面两个地方去,有什么不足和建议还请指教,如果你也想加入进来,可以留言或发email给我:

git:<a href="http://code.google.com/p/linuxzen/source/browse/water">http://code.google.com/p/linuxzen/source/browse/water</a>

svn:http://code.google.com/p/sharepythoncode/source/browse/water/
