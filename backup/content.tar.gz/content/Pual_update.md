title: Pual 更新支持SimSimi可以进行互动
date: 2013-05-30 09:50
tags: Pual, Python, bot, SimSimi
category: Python

[Pual](http://www.linuxzen.com/jie-yong-tornadoshi-xian-gao-xiao-de-webqqji-qi-ren.html) 跑了许久, 通过一段时间的修改现在Pual主要支持以下功能:

* 英汉互译
* 为每个用户分配一个session的含有上下文的Python shell
* 贴代码

----

总而言之就是一个被动型的辅助机器人, 群里有同学建议`AI`功能, 但是我水平不够没办法设计和实现`AI`部分, 所以想调用`SimSimi`实现`AI`, 发现官方Key才免费7天, 我这等穷苦人如何是买不起key的, google发现有一个非官方API可以调用, 但是被封了.但咱不是个容易放弃的人, 经过一番折腾非官方API可以正常调用, 所以Pual也有`AI`功能了, 只要在有Pual的群里发送`Pual`打头的消息 就可以和`Pual`互动

[项目地址](https://github.com/coldnight/pual_bot)

Pual帐号是:1685359365, 大家可以先加好友回答验证问题:cold, 然后将它拉入群内进行调戏
